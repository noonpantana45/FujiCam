package com.fujicam.app.camera

import android.content.Context
import android.content.res.Resources
import android.media.AudioManager
import android.media.MediaActionSound
import android.os.Build

/**
 * เสียงชัตเตอร์/เสียงอัดวิดีโอ ที่ทำตามการตั้งค่าเสียงของโทรศัพท์
 * - โทรศัพท์เปิดเสียง → มีเสียง
 * - โหมดเงียบ / สั่น หรือปิดเสียงระบบ → ไม่มีเสียง
 * - ยกเว้นเครื่องที่กฎหมายประเทศนั้นบังคับให้มีเสียงชัตเตอร์ (เช่น ญี่ปุ่น เกาหลี) จะเล่นเสมอ
 * เช็คใหม่ทุกครั้งที่กดถ่าย จึงตามทันถ้าผู้ใช้สลับโหมดเสียงระหว่างเปิดแอพ
 */
class ShutterSound(context: Context) {
    private val audio = context.applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val sound = MediaActionSound()
    private val forcedByLaw: Boolean = isForcedByLaw()

    fun load() {
        sound.load(MediaActionSound.SHUTTER_CLICK)
        sound.load(MediaActionSound.START_VIDEO_RECORDING)
        sound.load(MediaActionSound.STOP_VIDEO_RECORDING)
    }

    /** type = MediaActionSound.SHUTTER_CLICK / START_VIDEO_RECORDING / STOP_VIDEO_RECORDING */
    fun play(type: Int) {
        if (forcedByLaw || phoneSoundOn()) sound.play(type)
    }

    fun release() = sound.release()

    private fun phoneSoundOn(): Boolean = try {
        audio.ringerMode == AudioManager.RINGER_MODE_NORMAL &&
            audio.getStreamVolume(AudioManager.STREAM_SYSTEM) > 0
    } catch (e: Exception) {
        false
    }

    private fun isForcedByLaw(): Boolean {
        if (Build.VERSION.SDK_INT >= 33) return MediaActionSound.mustPlayShutterSound()
        // Android 10–12: อ่านค่าที่ผู้ผลิตตั้งไว้ในระบบ
        return try {
            val res = Resources.getSystem()
            val id = res.getIdentifier("config_camera_sound_forced", "bool", "android")
            id != 0 && res.getBoolean(id)
        } catch (e: Exception) {
            false
        }
    }
}
