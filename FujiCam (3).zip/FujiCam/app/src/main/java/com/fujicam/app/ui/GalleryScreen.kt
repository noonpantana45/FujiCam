package com.fujicam.app.ui

import android.app.Activity
import android.app.RecoverableSecurityException
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.fujicam.app.filters.FilmRolls
import com.fujicam.app.util.AppMedia
import com.fujicam.app.util.BitmapIO
import com.fujicam.app.util.toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class GalleryTab(val label: String) {
    ALL("ทั้งหมด"),
    FILM("สมุดฟิล์ม"),
    VIDEO("วิดีโอ"),
    ORIGINAL("ต้นฉบับ"),
}

/** อัลบั้มรูปของแอพ: รูป/วิดีโอใน Pictures/FujiCam และ Movies/FujiCam */
@Composable
fun GalleryScreen(
    onBack: () -> Unit,
    onEdit: (Uri) -> Unit,
    onFrameGrab: (Uri) -> Unit,
    onImport: () -> Unit,
) {
    val context = LocalContext.current
    var all by remember { mutableStateOf<List<AppMedia.Item>?>(null) }
    var tab by rememberSaveable { mutableStateOf(GalleryTab.ALL) }
    var viewing by remember { mutableStateOf<Int?>(null) }
    var reloadKey by remember { mutableIntStateOf(0) }

    LaunchedEffect(reloadKey) {
        all = withContext(Dispatchers.IO) { AppMedia.query(context) }
    }

    val items = remember(all, tab) {
        val list = all ?: emptyList()
        when (tab) {
            GalleryTab.ALL -> list.filter { !it.isOriginal }
            GalleryTab.FILM -> list.filter { it.isFilm && !it.isOriginal }
            GalleryTab.VIDEO -> list.filter { it.isVideo }
            GalleryTab.ORIGINAL -> list.filter { it.isOriginal }
        }
    }

    // ลบไฟล์: Android 11+ ระบบจะถามยืนยันก่อนเสมอ
    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            toast(context, "ลบแล้ว")
            viewing = null
            reloadKey++
        }
    }
    fun delete(item: AppMedia.Item) {
        val resolver = context.contentResolver
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                val req = MediaStore.createDeleteRequest(resolver, listOf(item.uri))
                deleteLauncher.launch(IntentSenderRequest.Builder(req.intentSender).build())
            } else {
                resolver.delete(item.uri, null, null)
                toast(context, "ลบแล้ว")
                viewing = null
                reloadKey++
            }
        } catch (e: RecoverableSecurityException) {
            deleteLauncher.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
        } catch (e: Exception) {
            toast(context, "ลบไม่ได้: ${e.message}")
        }
    }

    BackHandler {
        if (viewing != null) viewing = null else onBack()
    }

    val v = viewing
    if (v != null && v in items.indices) {
        Viewer(
            items = items,
            start = v,
            onClose = { viewing = null },
            onEdit = onEdit,
            onFrameGrab = onFrameGrab,
            onDelete = { delete(it) },
        )
        return
    }

    Column(Modifier.fillMaxSize().background(Color.Black).systemBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
            Text("อัลบั้ม", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.weight(1f))
            TextButton(onClick = onImport) { Text("นำเข้ารูปมาแต่ง", color = Yellow) }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            GalleryTab.entries.forEach { t -> Pill(t.label, t == tab) { tab = t } }
        }

        when {
            all == null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Yellow)
            }

            items.isEmpty() -> EmptyAlbum(tab, onImport)

            tab == GalleryTab.FILM -> FilmAlbum(items) { item -> viewing = items.indexOf(item) }

            else -> LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(2.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalArrangement = Arrangement.spacedBy(2.dp),
            ) {
                items(items, key = { it.uri.toString() }) { item ->
                    MediaCell(item) { viewing = items.indexOf(item) }
                }
            }
        }
    }
}

/** สมุดสะสมภาพฟิล์ม: จัดกลุ่มตามม้วน เรียงม้วนที่ถ่ายล่าสุดขึ้นก่อน */
@Composable
private fun FilmAlbum(items: List<AppMedia.Item>, onOpen: (AppMedia.Item) -> Unit) {
    val groups = remember(items) { items.groupBy { AppMedia.rollIdOf(it) } }
    LazyVerticalGrid(
        columns = GridCells.Fixed(3),
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(2.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
        groups.forEach { (rollId, list) ->
            val roll = FilmRolls.all.firstOrNull { it.id == rollId }
            item(span = { GridItemSpan(maxLineSpan) }, key = "h_" + (rollId ?: "other")) {
                Row(Modifier.padding(start = 10.dp, top = 14.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(width = 14.dp, height = 18.dp).clip(RoundedCornerShape(3.dp))
                            .background(roll?.let { Color(it.color) } ?: Color.Gray),
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(roll?.name ?: "ม้วนอื่น ๆ", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text("  ·  ${list.size} ภาพ", color = Color.White.copy(alpha = 0.6f), fontSize = 13.sp)
                }
            }
            items(list, key = { it.uri.toString() }) { item -> MediaCell(item) { onOpen(item) } }
        }
    }
}

@Composable
private fun EmptyAlbum(tab: GalleryTab, onImport: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            when (tab) {
                GalleryTab.FILM -> "ยังไม่มีภาพจากโหมดฟิล์ม\nลองเลื่อนแถบโหมดไปที่ ฟิล์ม แล้วถ่ายดู"
                GalleryTab.VIDEO -> "ยังไม่มีวิดีโอ"
                GalleryTab.ORIGINAL -> "ยังไม่มีรูปต้นฉบับ\nเปิด บันทึกรูปต้นฉบับคู่กัน ได้ในเมนู ⋮ ของหน้ากล้อง"
                GalleryTab.ALL -> "ยังไม่มีรูปที่ถ่ายด้วยแอพนี้"
            },
            color = Color.White.copy(alpha = 0.7f),
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(16.dp))
        OutlinedButton(onClick = onImport) {
            Icon(Icons.Filled.PhotoLibrary, null)
            Spacer(Modifier.width(8.dp))
            Text("นำเข้ารูปจากแกลเลอรี่มาแต่ง")
        }
    }
}

@Composable
private fun MediaCell(item: AppMedia.Item, onClick: () -> Unit) {
    val context = LocalContext.current
    var img by remember(item.uri) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(item.uri) {
        img = withContext(Dispatchers.IO) {
            runCatching { context.contentResolver.loadThumbnail(item.uri, Size(320, 320), null).asImageBitmap() }.getOrNull()
        }
    }
    Box(Modifier.aspectRatio(1f).background(Panel).clickable(onClick = onClick)) {
        img?.let { Image(it, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize()) }
        if (item.isVideo) {
            Icon(
                Icons.Filled.PlayArrow,
                "วิดีโอ",
                tint = Color.White,
                modifier = Modifier.align(Alignment.Center).size(30.dp)
                    .clip(CircleShape).background(Color.Black.copy(alpha = 0.45f)),
            )
        }
    }
}

@Composable
private fun Viewer(
    items: List<AppMedia.Item>,
    start: Int,
    onClose: () -> Unit,
    onEdit: (Uri) -> Unit,
    onFrameGrab: (Uri) -> Unit,
    onDelete: (AppMedia.Item) -> Unit,
) {
    val context = LocalContext.current
    val pager = rememberPagerState(initialPage = start) { items.size }
    var confirmDelete by remember { mutableStateOf(false) }
    val current = items.getOrNull(pager.currentPage) ?: return

    fun open(item: AppMedia.Item) {
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(item.uri, if (item.isVideo) "video/*" else "image/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            toast(context, "ไม่พบแอพสำหรับเปิดไฟล์")
        }
    }

    fun share(item: AppMedia.Item) {
        val send = Intent(Intent.ACTION_SEND)
            .setType(if (item.isVideo) "video/*" else "image/*")
            .putExtra(Intent.EXTRA_STREAM, item.uri)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        context.startActivity(Intent.createChooser(send, "แชร์"))
    }

    Column(Modifier.fillMaxSize().background(Color.Black).systemBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onClose) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
            Column(Modifier.weight(1f)) {
                Text(
                    SimpleDateFormat("d MMM yyyy  HH:mm", Locale("th", "TH")).format(Date(current.added * 1000)),
                    color = Color.White,
                    fontSize = 14.sp,
                )
                Text("${pager.currentPage + 1} / ${items.size}", color = Color.White.copy(alpha = 0.6f), fontSize = 11.sp)
            }
        }

        HorizontalPager(state = pager, modifier = Modifier.weight(1f).fillMaxWidth()) { page ->
            ViewerPage(items[page]) { open(items[page]) }
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            ViewerAction(Icons.Filled.Share, "แชร์") { share(current) }
            if (current.isVideo) {
                ViewerAction(Icons.Filled.Movie, "แคปเฟรม") { onFrameGrab(current.uri) }
            } else {
                ViewerAction(Icons.Filled.Edit, "แต่ง") { onEdit(current.uri) }
            }
            ViewerAction(Icons.Filled.OpenInNew, "เปิดด้วย") { open(current) }
            ViewerAction(Icons.Filled.Delete, "ลบ") { confirmDelete = true }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("ลบไฟล์นี้?") },
            text = { Text("ไฟล์จะถูกลบออกจากเครื่อง") },
            confirmButton = {
                TextButton(onClick = {
                    confirmDelete = false
                    onDelete(current)
                }) { Text("ลบ", color = Color(0xFFFF453A)) }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("ยกเลิก") } },
        )
    }
}

@Composable
private fun ViewerPage(item: AppMedia.Item, onPlay: () -> Unit) {
    val context = LocalContext.current
    var img by remember(item.uri) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(item.uri) {
        img = withContext(Dispatchers.IO) {
            runCatching {
                if (item.isVideo) {
                    context.contentResolver.loadThumbnail(item.uri, Size(1280, 1280), null).asImageBitmap()
                } else {
                    BitmapIO.load(context, item.uri, maxDim = 2048).asImageBitmap()
                }
            }.getOrNull()
        }
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val i = img
        if (i == null) {
            CircularProgressIndicator(color = Yellow)
        } else {
            Image(i, null, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
        }
        if (item.isVideo) {
            Box(
                Modifier.size(64.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.5f)).clickable(onClick = onPlay),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.PlayArrow, "เล่นวิดีโอ", tint = Color.White, modifier = Modifier.size(40.dp)) }
        }
    }
}

@Composable
private fun ViewerAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, label, tint = Color.White)
        Text(label, color = Color.White, fontSize = 11.sp)
    }
}
