package com.fujicam.app.filters

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.Random
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** ค่าปรับแต่งเพิ่มเติมจากผู้ใช้ (ใช้ในหน้าแต่งรูป) */
data class Adjustments(
    val brightness: Float = 0f, // -1..1
    val contrast: Float = 0f,   // -1..1
    val saturation: Float = 0f, // -1..1
    val warmth: Float = 0f,     // -1..1
    val tint: Float = 0f,       // -1..1
    val fade: Float = 0f,       // 0..1
    val vignette: Float = 0f,   // 0..1
    val grain: Float = 0f,      // 0..1
) {
    val isNeutral: Boolean get() = this == NONE

    companion object {
        val NONE = Adjustments()
    }
}

object FilterEngine {

    // ---------------- เมทริกซ์สี ----------------

    fun adjustMatrix(a: Adjustments): FloatArray {
        var m = CM.identity()
        if (a.saturation != 0f) m = CM.concat(m, CM.saturation(1f + a.saturation))
        if (a.warmth != 0f || a.tint != 0f) m = CM.concat(m, CM.temperature(a.warmth, a.tint))
        if (a.contrast != 0f) m = CM.concat(m, CM.contrast(1f + a.contrast * 0.5f))
        if (a.brightness != 0f) {
            val o = a.brightness * 64f
            m = CM.concat(m, CM.offset(o, o, o))
        }
        if (a.fade != 0f) m = CM.concat(m, CM.fade(a.fade * 0.2f))
        return m
    }

    /** เมทริกซ์สุดท้าย = ฟิลเตอร์ (ตามความเข้ม) แล้วตามด้วยค่าปรับแต่ง */
    fun matrixFor(look: FilmLook, adj: Adjustments, intensity: Float): FloatArray {
        val base = if (look.isOriginal) CM.identity() else CM.lerp(CM.identity(), look.matrix, intensity)
        return if (adj.isNeutral) base else CM.concat(base, adjustMatrix(adj))
    }

    fun grainOf(look: FilmLook, adj: Adjustments, intensity: Float) = (look.grain * intensity + adj.grain).coerceIn(0f, 1f)
    fun vignetteOf(look: FilmLook, adj: Adjustments, intensity: Float) = (look.vignette * intensity + adj.vignette).coerceIn(0f, 1f)
    fun leakOf(look: FilmLook, intensity: Float) = (look.leak * intensity).coerceIn(0f, 1f)

    /** แปลงเป็นเมทริกซ์ 4x4 (column-major, ค่า 0..1) สำหรับ Media3 RgbMatrix */
    fun toMedia3Matrix(cm: FloatArray): FloatArray {
        val out = FloatArray(16)
        for (row in 0 until 3) {
            for (col in 0 until 3) out[col * 4 + row] = cm[row * 5 + col]
            out[3 * 4 + row] = cm[row * 5 + 4] / 255f
        }
        out[15] = 1f
        return out
    }

    // ---------------- เกรนฟิล์ม ----------------

    /** แผ่นเกรนสีเทากลาง (128) สุ่มแบบ gaussian ใช้ทั้งพรีวิวและรูปจริง */
    val grainTile: Bitmap by lazy {
        val n = 512
        val rnd = Random(7)
        val px = IntArray(n * n) {
            val v = (128 + rnd.nextGaussian() * 46).roundToInt().coerceIn(0, 255)
            Color.rgb(v, v, v)
        }
        Bitmap.createBitmap(px, n, n, Bitmap.Config.ARGB_8888)
    }

    // ---------------- เรนเดอร์ภาพ ----------------

    /** ใส่ฟิลเตอร์ให้รูปที่ความละเอียดเต็ม คืน Bitmap ใหม่ (ไม่แตะต้นฉบับ) */
    fun render(
        src: Bitmap,
        look: FilmLook,
        adj: Adjustments,
        intensity: Float,
        dateStamp: Boolean,
        time: Long = System.currentTimeMillis(),
    ): Bitmap {
        val w = src.width
        val h = src.height
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            colorFilter = ColorMatrixColorFilter(matrixFor(look, adj, intensity))
        }
        c.drawBitmap(src, 0f, 0f, paint)

        val leak = leakOf(look, intensity)
        if (leak > 0f) drawLeak(c, w, h, leak)
        val vig = vignetteOf(look, adj, intensity)
        if (vig > 0f) drawVignette(c, w, h, vig)
        val grain = grainOf(look, adj, intensity)
        if (grain > 0f) drawGrain(c, w, h, grain)
        if (dateStamp) drawDateStamp(c, w, h, time)
        return out
    }

    private fun drawLeak(c: Canvas, w: Int, h: Int, amount: Float) {
        val a = (amount * 220).roundToInt().coerceIn(0, 255)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                w * 0.95f, h * 0.05f, max(w, h) * 0.8f,
                intArrayOf(Color.argb(a, 255, 110, 30), Color.argb(a / 2, 255, 60, 60), Color.argb(0, 255, 40, 0)),
                floatArrayOf(0f, 0.45f, 1f), Shader.TileMode.CLAMP,
            )
            xfermode = PorterDuffXfermode(PorterDuff.Mode.SCREEN)
        }
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
    }

    private fun drawVignette(c: Canvas, w: Int, h: Int, amount: Float) {
        val cx = w / 2f
        val cy = h / 2f
        val a = (amount * 235).roundToInt().coerceIn(0, 255)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = RadialGradient(
                cx, cy, hypot(cx, cy),
                intArrayOf(Color.TRANSPARENT, Color.TRANSPARENT, Color.argb(a, 0, 0, 0)),
                floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP,
            )
        }
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
    }

    private fun drawGrain(c: Canvas, w: Int, h: Int, amount: Float) {
        // ขยายเกรนตามขนาดภาพ เพื่อให้ "ขนาดเม็ด" ดูเท่ากันทั้งพรีวิวและไฟล์จริง
        val s = max(1f, min(w, h) / 1100f)
        val shader = BitmapShader(grainTile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT).apply {
            setLocalMatrix(Matrix().apply { setScale(s, s) })
        }
        val p = Paint(Paint.FILTER_BITMAP_FLAG).apply {
            this.shader = shader
            alpha = (amount * 150).roundToInt().coerceIn(0, 255)
            xfermode = PorterDuffXfermode(PorterDuff.Mode.OVERLAY)
        }
        c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
    }

    // ---------------- ตัวเลขวันที่สีส้มแบบกล้องฟิล์ม ----------------

    fun dateStampText(time: Long): String = SimpleDateFormat("''yy MM dd", Locale.US).format(Date(time))

    fun drawDateStamp(c: Canvas, w: Int, h: Int, time: Long) {
        val size = min(w, h) * 0.045f
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.rgb(255, 150, 40)
            textSize = size
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
            setShadowLayer(size * 0.35f, 0f, 0f, Color.argb(200, 255, 80, 0))
        }
        val margin = min(w, h) * 0.05f
        c.drawText(dateStampText(time), w - margin, h - margin, p)
    }

    fun drawDateStamp(bmp: Bitmap, time: Long) = drawDateStamp(Canvas(bmp), bmp.width, bmp.height, time)

    // ---------------- รวมภาพกล้องหน้า+หลัง ----------------

    /** กล้องหลังเต็มภาพ + กล้องหน้าเป็นกรอบเล็กมุมซ้ายบน */
    fun composeDual(back: Bitmap, front: Bitmap): Bitmap {
        val out = back.copy(Bitmap.Config.ARGB_8888, true)
        val c = Canvas(out)
        val w = out.width.toFloat()
        val pipW = w * 0.32f
        val pipH = pipW * front.height / front.width
        val m = w * 0.04f
        val rect = RectF(m, m, m + pipW, m + pipH)
        val r = pipW * 0.09f
        val border = w * 0.006f
        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        c.drawRoundRect(
            RectF(rect.left - border, rect.top - border, rect.right + border, rect.bottom + border),
            r + border, r + border, borderPaint,
        )
        c.save()
        c.clipPath(Path().apply { addRoundRect(rect, r, r, Path.Direction.CW) })
        c.drawBitmap(front, null, rect, Paint(Paint.FILTER_BITMAP_FLAG))
        c.restore()
        return out
    }
}
