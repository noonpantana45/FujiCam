package com.fujicam.app.util

import android.app.Activity
import android.content.ContentValues
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.core.content.ContextCompat
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sqrt

fun toast(context: Context, msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

fun hasPermission(context: Context, permission: String) =
    ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED

fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

fun formatNanos(nanos: Long): String {
    val s = nanos / 1_000_000_000L
    return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
}

/** บันทึกไฟล์ลงแกลเลอรี่ (Pictures/FujiCam และ Movies/FujiCam) */
object MediaSaver {
    private const val FOLDER = "FujiCam"
    private val seq = AtomicInteger()

    private fun fileName(prefix: String, ext: String): String {
        val ts = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        return "${prefix}_${ts}_${seq.incrementAndGet()}.$ext"
    }

    fun saveBitmap(
        context: Context,
        bmp: Bitmap,
        png: Boolean = false,
        quality: Int = 95,
        prefix: String = "FJC",
    ): Uri? {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName(prefix, if (png) "png" else "jpg"))
            put(MediaStore.MediaColumns.MIME_TYPE, if (png) "image/png" else "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_PICTURES}/$FOLDER")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            resolver.openOutputStream(uri)?.use { os ->
                bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, quality, os)
            } ?: throw IOException("open stream failed")
            resolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            null
        }
    }

    fun saveVideo(context: Context, file: File): Uri? {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName("FJC_VID", "mp4"))
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "${Environment.DIRECTORY_MOVIES}/$FOLDER")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        return try {
            resolver.openOutputStream(uri)?.use { out ->
                file.inputStream().use { it.copyTo(out, 1 shl 16) }
            } ?: throw IOException("open stream failed")
            resolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            null
        }
    }
}

object BitmapIO {
    /**
     * โหลดรูปจาก Uri (หมุนตาม EXIF ให้อัตโนมัติ)
     * maxDim = 0 คือความละเอียดเต็ม แต่จำกัดไม่เกิน maxPixels กันแรมเต็ม
     */
    fun load(context: Context, uri: Uri, maxDim: Int = 0, maxPixels: Long = 24_000_000L): Bitmap {
        val src = ImageDecoder.createSource(context.contentResolver, uri)
        return ImageDecoder.decodeBitmap(src) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val w = info.size.width
            val h = info.size.height
            var scale = 1f
            if (maxDim > 0 && max(w, h) > maxDim) scale = maxDim.toFloat() / max(w, h)
            val px = w.toLong() * h
            if (px * scale * scale > maxPixels) scale = sqrt(maxPixels.toFloat() / px)
            if (scale < 1f) {
                decoder.setTargetSize(max(1, (w * scale).roundToInt()), max(1, (h * scale).roundToInt()))
            }
        }
    }

    /** หมุน/กลับด้านภาพ */
    fun transform(src: Bitmap, rotation: Int, mirror: Boolean, recycleSource: Boolean): Bitmap {
        if (rotation % 360 == 0 && !mirror) return src
        val m = Matrix().apply {
            postRotate(rotation.toFloat())
            if (mirror) postScale(-1f, 1f)
        }
        val out = Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
        if (recycleSource && out !== src) src.recycle()
        return out
    }

    fun scaleToMax(src: Bitmap, maxDim: Int): Bitmap {
        val m = max(src.width, src.height)
        if (m <= maxDim) return src
        val s = maxDim.toFloat() / m
        return Bitmap.createScaledBitmap(src, max(1, (src.width * s).roundToInt()), max(1, (src.height * s).roundToInt()), true)
    }

    /** วันที่ถ่ายจาก EXIF (ใช้กับตัวเลขวันที่สีส้ม) */
    fun exifDate(context: Context, uri: Uri): Long? = try {
        context.contentResolver.openInputStream(uri)?.use { input ->
            val exif = ExifInterface(input)
            val s = exif.getAttribute(ExifInterface.TAG_DATETIME_ORIGINAL)
                ?: exif.getAttribute(ExifInterface.TAG_DATETIME)
            s?.let { SimpleDateFormat("yyyy:MM:dd HH:mm:ss", Locale.US).parse(it)?.time }
        }
    } catch (e: Exception) {
        null
    }
}

/** จำค่าตั้งค่าไว้ใช้ครั้งหน้า */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("fujicam", Context.MODE_PRIVATE)

    var lookId: String
        get() = sp.getString("look", "provia") ?: "provia"
        set(v) = sp.edit().putString("look", v).apply()
    var intensity: Float
        get() = sp.getFloat("intensity", 1f)
        set(v) = sp.edit().putFloat("intensity", v).apply()
    var dateStamp: Boolean
        get() = sp.getBoolean("dateStamp", false)
        set(v) = sp.edit().putBoolean("dateStamp", v).apply()
    var grid: Boolean
        get() = sp.getBoolean("grid", false)
        set(v) = sp.edit().putBoolean("grid", v).apply()
    var mirrorFront: Boolean
        get() = sp.getBoolean("mirrorFront", true)
        set(v) = sp.edit().putBoolean("mirrorFront", v).apply()
    var uhd: Boolean
        get() = sp.getBoolean("uhd", false)
        set(v) = sp.edit().putBoolean("uhd", v).apply()

    // โหมดกล้องฟิล์ม
    var rollId: String
        get() = sp.getString("rollId", "quicksnap") ?: "quicksnap"
        set(v) = sp.edit().putString("rollId", v).apply()
    var shotsLeft: Int
        get() = sp.getInt("shotsLeft", -1)
        set(v) = sp.edit().putInt("shotsLeft", v).apply()
    /** ว่าง = ใช้ขอบตั้งต้นของม้วน */
    var filmBorder: String
        get() = sp.getString("filmBorder", "") ?: ""
        set(v) = sp.edit().putString("filmBorder", v).apply()
    var filmDate: Boolean
        get() = sp.getBoolean("filmDate", true)
        set(v) = sp.edit().putBoolean("filmDate", v).apply()
}
