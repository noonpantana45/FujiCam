package com.fujicam.app.camera

import android.content.Context
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.RgbMatrix
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.fujicam.app.filters.CM
import com.fujicam.app.filters.FilterEngine
import com.fujicam.app.util.MediaSaver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.Closeable
import java.io.File
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.math.max
import kotlin.math.roundToInt

/** หลังอัดเสร็จ: ใส่สีฟิลเตอร์ (ถ้ามี) แล้วบันทึกลงแกลเลอรี่ */
object VideoPipeline {
    suspend fun finish(context: Context, file: File, colorMatrix: FloatArray): Uri? {
        var src = file
        if (!CM.isIdentity(colorMatrix)) {
            val out = File(context.cacheDir, "flt_" + file.name)
            val ok = VideoFilter.apply(context.applicationContext, file, colorMatrix, out)
            if (ok) src = out else out.delete() // ถ้าใส่ฟิลเตอร์ไม่สำเร็จ เก็บต้นฉบับไว้แทน
        }
        return withContext(Dispatchers.IO) {
            val uri = MediaSaver.saveVideo(context, src)
            file.delete()
            if (src != file) src.delete()
            uri
        }
    }
}

@OptIn(UnstableApi::class)
object VideoFilter {
    suspend fun apply(context: Context, input: File, colorMatrix: FloatArray, output: File): Boolean =
        withContext(Dispatchers.Main) {
            suspendCancellableCoroutine<Boolean> { cont ->
                val m = FilterEngine.toMedia3Matrix(colorMatrix)
                val effect = object : RgbMatrix {
                    override fun getMatrix(presentationTimeUs: Long, useHdr: Boolean): FloatArray = m
                }
                val item = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(input)))
                    .setEffects(Effects(emptyList(), listOf<Effect>(effect)))
                    .build()
                val transformer = Transformer.Builder(context)
                    .addListener(object : Transformer.Listener {
                        override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                            if (cont.isActive) cont.resume(true)
                        }

                        override fun onError(
                            composition: Composition,
                            exportResult: ExportResult,
                            exportException: ExportException,
                        ) {
                            Log.e("VideoFilter", "export failed", exportException)
                            if (cont.isActive) cont.resume(false)
                        }
                    })
                    .build()
                transformer.start(item, output.absolutePath)
                cont.invokeOnCancellation { Handler(Looper.getMainLooper()).post { transformer.cancel() } }
            }
        }
}

/**
 * ดึงเฟรมจากวิดีโอที่ความละเอียดเต็มของไฟล์ (ไม่ย่อ ไม่บีบอัดซ้ำ)
 * ใช้ MediaMetadataRetriever บนเธรดเดียวของตัวเอง
 */
class FrameGrabber(private val context: Context, private val uri: Uri) : Closeable {

    data class Info(val width: Int, val height: Int, val durationMs: Long, val frameCount: Int, val fps: Float) {
        val totalFrames: Int get() = if (frameCount > 0) frameCount else max(1, (durationMs / 1000f * fps).roundToInt())
        fun timeMsOf(index: Int): Long = (index * 1000.0 / fps).toLong()
    }

    private val executor = Executors.newSingleThreadExecutor()
    private val dispatcher = executor.asCoroutineDispatcher()
    private val mmr = MediaMetadataRetriever()
    private var info: Info? = null
    private var indexAccessOk = true

    suspend fun open(): Info? = withContext(dispatcher) {
        try {
            mmr.setDataSource(context, uri)
            fun meta(key: Int) = mmr.extractMetadata(key)
            val w = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val h = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val rot = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            val dur = meta(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val count = meta(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT)?.toIntOrNull() ?: 0
            val fps = if (count > 0 && dur > 0) count * 1000f / dur
            else meta(MediaMetadataRetriever.METADATA_KEY_CAPTURE_FRAMERATE)?.toFloatOrNull() ?: 30f
            val swap = rot == 90 || rot == 270
            Info(if (swap) h else w, if (swap) w else h, dur, count, fps).also { info = it }
        } catch (e: Exception) {
            Log.e("FrameGrabber", "open failed", e)
            null
        }
    }

    suspend fun frameAt(index: Int): Bitmap? = withContext(dispatcher) {
        val inf = info ?: return@withContext null
        var bmp: Bitmap? = null
        // ใช้ index ก่อน (แม่นยำระดับเฟรม)
        if (inf.frameCount > 0 && indexAccessOk) {
            bmp = try {
                val params = MediaMetadataRetriever.BitmapParams().apply { preferredConfig = Bitmap.Config.ARGB_8888 }
                mmr.getFrameAtIndex(index.coerceIn(0, inf.frameCount - 1), params)
            } catch (e: Exception) {
                indexAccessOk = false
                null
            }
        }
        if (bmp == null) {
            val us = inf.timeMsOf(index) * 1000L
            bmp = try {
                if (Build.VERSION.SDK_INT >= 30) {
                    val params = MediaMetadataRetriever.BitmapParams().apply { preferredConfig = Bitmap.Config.ARGB_8888 }
                    mmr.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST, params)
                } else {
                    mmr.getFrameAtTime(us, MediaMetadataRetriever.OPTION_CLOSEST)
                }
            } catch (e: Exception) {
                null
            }
        }
        bmp
    }

    override fun close() {
        executor.execute {
            try {
                mmr.release()
            } catch (_: Exception) {
            }
        }
        executor.shutdown()
    }
}
