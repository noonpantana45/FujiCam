package com.fujicam.app.ui

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.fujicam.app.filters.FilmLook
import com.fujicam.app.filters.FilmLooks
import com.fujicam.app.filters.FilterEngine
import com.fujicam.app.filters.LookGroup
import com.fujicam.app.util.Prefs
import com.fujicam.app.util.hasPermission
import kotlin.math.roundToInt

val Yellow = Color(0xFFFFD60A)
val Orange = Color(0xFFFF9F0A)
val Panel = Color(0xFF1C1C1E)

@Composable
fun FujiCamTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Yellow,
            onPrimary = Color.Black,
            secondary = Orange,
            background = Color.Black,
            surface = Panel,
        ),
        content = content,
    )
}

// ======================= การนำทางระหว่างหน้า =======================

sealed interface Screen {
    data object Camera : Screen
    data class Editor(val uri: Uri) : Screen
    data class FrameGrab(val uri: Uri?) : Screen
}

@Composable
fun AppRoot(registerVolumeKey: ((() -> Unit)?) -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val prefs = remember { Prefs(context) }
    var screen by remember { mutableStateOf<Screen>(Screen.Camera) }
    var lookId by remember { mutableStateOf(prefs.lookId) }
    var intensity by remember { mutableFloatStateOf(prefs.intensity) }
    var cameraGranted by remember { mutableStateOf(hasPermission(context, Manifest.permission.CAMERA)) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        cameraGranted = hasPermission(context, Manifest.permission.CAMERA)
    }
    LaunchedEffect(Unit) {
        val need = listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            .filterNot { hasPermission(context, it) }
        if (need.isNotEmpty()) permissionLauncher.launch(need.toTypedArray())
    }
    // กลับมาจากหน้าตั้งค่า → เช็คสิทธิ์ใหม่
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) cameraGranted = hasPermission(context, Manifest.permission.CAMERA)
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) screen = Screen.Editor(uri)
    }
    val pickPhoto: () -> Unit = {
        photoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    when (val s = screen) {
        Screen.Camera -> if (cameraGranted) {
            CameraScreen(
                lookId = lookId,
                intensity = intensity,
                onLookChange = { lookId = it; prefs.lookId = it },
                onIntensityChange = { intensity = it; prefs.intensity = it },
                onPickPhoto = pickPhoto,
                onOpenFrameGrab = { screen = Screen.FrameGrab(it) },
                onEditUri = { screen = Screen.Editor(it) },
                registerVolumeKey = registerVolumeKey,
            )
        } else {
            PermissionScreen(
                onRequest = {
                    permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
                },
                onOpenSettings = {
                    context.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                },
                onPickPhoto = pickPhoto,
                onFrameGrab = { screen = Screen.FrameGrab(null) },
            )
        }

        is Screen.Editor -> EditorScreen(uri = s.uri, initialLookId = lookId, onBack = { screen = Screen.Camera })
        is Screen.FrameGrab -> FrameGrabScreen(
            initialUri = s.uri,
            onBack = { screen = Screen.Camera },
            onEdit = { screen = Screen.Editor(it) },
        )
    }
}

@Composable
private fun PermissionScreen(
    onRequest: () -> Unit,
    onOpenSettings: () -> Unit,
    onPickPhoto: () -> Unit,
    onFrameGrab: () -> Unit,
) {
    Column(
        Modifier.fillMaxSize().background(Color.Black).systemBarsPadding().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("FujiCam ต้องใช้กล้อง", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text(
            "อนุญาตกล้องเพื่อถ่ายรูปและวิดีโอ และอนุญาตไมโครโฟนถ้าต้องการเสียงในวิดีโอ",
            color = Color.White.copy(alpha = 0.7f),
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(24.dp))
        Button(onClick = onRequest) { Text("อนุญาตกล้อง") }
        TextButton(onClick = onOpenSettings) { Text("เปิดการตั้งค่าแอพ") }
        Spacer(Modifier.height(32.dp))
        OutlinedButton(onClick = onPickPhoto) {
            Icon(Icons.Filled.PhotoLibrary, null)
            Spacer(Modifier.width(8.dp))
            Text("แต่งรูปจากแกลเลอรี่")
        }
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onFrameGrab) {
            Icon(Icons.Filled.Movie, null)
            Spacer(Modifier.width(8.dp))
            Text("แคปภาพจากวิดีโอ")
        }
    }
}

// ======================= ชิ้นส่วนที่ใช้ร่วมกัน =======================

@Composable
fun yellowSlider() = SliderDefaults.colors(
    thumbColor = Yellow,
    activeTrackColor = Yellow,
    inactiveTrackColor = Color.White.copy(alpha = 0.25f),
    activeTickColor = Color.Transparent,
    inactiveTickColor = Color.Transparent,
)

@Composable
fun LabeledSlider(
    label: String,
    value: Float,
    onChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float> = 0f..1f,
    showSigned: Boolean = false,
) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.width(76.dp))
        Slider(value = value, onValueChange = onChange, valueRange = range, colors = yellowSlider(), modifier = Modifier.weight(1f))
        val pct = (value * 100).roundToInt()
        Text(
            if (showSigned && pct > 0) "+$pct" else "$pct",
            color = Color.White.copy(alpha = 0.8f),
            fontSize = 12.sp,
            textAlign = TextAlign.End,
            modifier = Modifier.width(40.dp),
        )
    }
}

@Composable
fun TopIcon(icon: ImageVector, tint: Color = Color.White, enabled: Boolean = true, onClick: () -> Unit) {
    IconButton(onClick = onClick, enabled = enabled) {
        Icon(icon, contentDescription = null, tint = if (enabled) tint else tint.copy(alpha = 0.3f))
    }
}

@Composable
fun RoundButton(icon: ImageVector, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        Modifier.size(54.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.15f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, null, tint = Color.White.copy(alpha = if (enabled) 1f else 0.3f), modifier = Modifier.size(28.dp))
    }
}

@Composable
fun DateStampLabel(modifier: Modifier = Modifier, time: Long = System.currentTimeMillis()) {
    Text(
        FilterEngine.dateStampText(time),
        modifier = modifier,
        color = Color(0xFFFF9628),
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.Bold,
        fontSize = 15.sp,
        style = TextStyle(shadow = Shadow(color = Color(0xFFFF5000), blurRadius = 14f)),
    )
}

/** แถบเลือกฟิลเตอร์: แท็บหมวด + รูปตัวอย่างของแต่ละฟิลเตอร์ */
@Composable
fun FilterStrip(
    thumb: ImageBitmap?,
    selectedId: String,
    onSelect: (FilmLook) -> Unit,
    modifier: Modifier = Modifier,
) {
    var group by rememberSaveable { mutableStateOf(LookGroup.ALL) }
    val looks = remember(group) { FilmLooks.inGroup(group) }
    Column(modifier) {
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(horizontal = 12.dp),
        ) {
            items(LookGroup.entries) { g ->
                val sel = g == group
                Text(
                    g.label,
                    color = if (sel) Color.Black else Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(50))
                        .background(if (sel) Yellow else Color.White.copy(alpha = 0.12f))
                        .clickable { group = g }
                        .padding(horizontal = 12.dp, vertical = 5.dp),
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(horizontal = 12.dp),
        ) {
            items(looks, key = { it.id }) { look ->
                FilterItem(look, thumb, look.id == selectedId) { onSelect(look) }
            }
        }
    }
}

@Composable
private fun FilterItem(look: FilmLook, thumb: ImageBitmap?, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    val filter = remember(look.id) { ColorFilter.colorMatrix(ColorMatrix(look.matrix)) }
    Column(
        Modifier.width(68.dp).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier.size(64.dp).clip(shape).background(Panel)
                .border(if (selected) 2.dp else 0.5.dp, if (selected) Yellow else Color.White.copy(alpha = 0.2f), shape),
        ) {
            if (thumb != null) {
                Image(
                    thumb,
                    contentDescription = look.name,
                    contentScale = ContentScale.Crop,
                    colorFilter = if (look.isOriginal) null else filter,
                    modifier = Modifier.fillMaxSize().clip(shape),
                )
            }
        }
        Spacer(Modifier.height(4.dp))
        Text(
            look.name,
            color = if (selected) Yellow else Color.White,
            fontSize = 10.sp,
            lineHeight = 12.sp,
            maxLines = 2,
            textAlign = TextAlign.Center,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        )
    }
}
