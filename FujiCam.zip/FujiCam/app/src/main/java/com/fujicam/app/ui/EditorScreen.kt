package com.fujicam.app.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CropRotate
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.lifecycleScope
import com.fujicam.app.filters.Adjustments
import com.fujicam.app.filters.Border
import com.fujicam.app.filters.FilmLooks
import com.fujicam.app.filters.FilterEngine
import com.fujicam.app.util.BitmapIO
import com.fujicam.app.util.MediaSaver
import com.fujicam.app.util.toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private enum class AdjKey(val label: String, val signed: Boolean) {
    BRIGHTNESS("ความสว่าง", true),
    CONTRAST("คอนทราสต์", true),
    SATURATION("ความอิ่มสี", true),
    WARMTH("อุณหภูมิสี", true),
    TINT("เขียว-ม่วง", true),
    FADE("ซีดจาง", false),
}

private fun Adjustments.get(k: AdjKey): Float = when (k) {
    AdjKey.BRIGHTNESS -> brightness
    AdjKey.CONTRAST -> contrast
    AdjKey.SATURATION -> saturation
    AdjKey.WARMTH -> warmth
    AdjKey.TINT -> tint
    AdjKey.FADE -> fade
}

private fun Adjustments.with(k: AdjKey, v: Float): Adjustments = when (k) {
    AdjKey.BRIGHTNESS -> copy(brightness = v)
    AdjKey.CONTRAST -> copy(contrast = v)
    AdjKey.SATURATION -> copy(saturation = v)
    AdjKey.WARMTH -> copy(warmth = v)
    AdjKey.TINT -> copy(tint = v)
    AdjKey.FADE -> copy(fade = v)
}

@Composable
fun EditorScreen(uri: Uri, initialLookId: String, onBack: () -> Unit) {
    val context = LocalContext.current
    val workScope = LocalLifecycleOwner.current.lifecycleScope
    BackHandler(onBack = onBack)

    var source by remember { mutableStateOf<Bitmap?>(null) }
    var loadError by remember { mutableStateOf(false) }
    var stampTime by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var rotation by remember { mutableIntStateOf(0) }
    var lookId by remember { mutableStateOf(initialLookId) }
    var intensity by remember { mutableFloatStateOf(1f) }
    var adj by remember { mutableStateOf(Adjustments()) }
    var stamp by remember { mutableStateOf(false) }
    var border by remember { mutableStateOf(Border.NONE) }
    var tab by remember { mutableIntStateOf(0) }
    var adjKey by remember { mutableStateOf(AdjKey.BRIGHTNESS) }
    var rendered by remember { mutableStateOf<ImageBitmap?>(null) }
    var showOriginal by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }

    LaunchedEffect(uri) {
        try {
            val (bmp, date) = withContext(Dispatchers.IO) {
                BitmapIO.load(context, uri, maxDim = 1800) to BitmapIO.exifDate(context, uri)
            }
            source = bmp
            if (date != null) stampTime = date
        } catch (e: Exception) {
            loadError = true
        }
    }

    val look = remember(lookId) { FilmLooks.byId(lookId) }
    val base = remember(source, rotation) { source?.let { BitmapIO.transform(it, rotation, false, recycleSource = false) } }
    val baseImage = remember(base) { base?.asImageBitmap() }
    val thumb = remember(source) { source?.let { BitmapIO.scaleToMax(it, 160).asImageBitmap() } }

    // พรีวิวใช้ตัวเรนเดอร์เดียวกับไฟล์จริง จึงเห็นผลตรงกับที่บันทึก
    LaunchedEffect(base, lookId, intensity, adj, stamp, stampTime, border) {
        val b = base ?: return@LaunchedEffect
        delay(30)
        val out = withContext(Dispatchers.Default) {
            FilterEngine.render(b, look, adj, intensity, stamp, stampTime, border = border)
        }
        rendered = out.asImageBitmap()
    }

    fun save() {
        if (saving) return
        saving = true
        val snapLook = look
        val snapAdj = adj
        val snapIntensity = intensity
        val snapStamp = stamp
        val snapRotation = rotation
        val snapTime = stampTime
        val snapBorder = border
        workScope.launch {
            val result = withContext(Dispatchers.Default) {
                runCatching {
                    val full = BitmapIO.load(context, uri) // ความละเอียดเต็ม
                    val rot = BitmapIO.transform(full, snapRotation, false, recycleSource = true)
                    val out = FilterEngine.render(rot, snapLook, snapAdj, snapIntensity, snapStamp, snapTime, border = snapBorder)
                    rot.recycle()
                    val u = MediaSaver.saveBitmap(context, out, quality = 95, prefix = "FJC_EDIT")
                    val size = "${out.width}×${out.height}"
                    out.recycle()
                    if (u != null) size else null
                }.getOrNull()
            }
            saving = false
            toast(context, if (result != null) "บันทึกรูปแล้ว ($result)" else "บันทึกรูปไม่สำเร็จ")
        }
    }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {
            Row(
                Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
                Text("แต่งรูป", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                IconButton(onClick = { rotation = (rotation + 90) % 360 }) {
                    Icon(Icons.Filled.CropRotate, null, tint = Color.White)
                }
                TextButton(onClick = { save() }, enabled = base != null && !saving) {
                    Text("บันทึก", color = Yellow, fontWeight = FontWeight.Bold)
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) {
                val shown = if (showOriginal) baseImage else (rendered ?: baseImage)
                when {
                    loadError -> Text("เปิดรูปนี้ไม่ได้ ลองเลือกรูปอื่น", color = Color.White)
                    shown == null -> CircularProgressIndicator(color = Yellow)
                    else -> {
                        Image(
                            shown,
                            contentDescription = null,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize().pointerInput(Unit) {
                                // แตะค้างเพื่อดูต้นฉบับ
                                detectTapGestures(onPress = {
                                    showOriginal = true
                                    tryAwaitRelease()
                                    showOriginal = false
                                })
                            },
                        )
                        if (showOriginal) {
                            Text(
                                "ต้นฉบับ",
                                color = Color.White,
                                fontSize = 12.sp,
                                modifier = Modifier.align(Alignment.TopCenter)
                                    .clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.6f))
                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                            )
                        }
                    }
                }
            }

            Text(
                "แตะค้างที่รูปเพื่อเทียบกับต้นฉบับ",
                color = Color.White.copy(alpha = 0.5f),
                fontSize = 11.sp,
                modifier = Modifier.align(Alignment.CenterHorizontally),
            )

            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(24.dp, Alignment.CenterHorizontally),
            ) {
                listOf("ฟิลเตอร์", "ปรับแสง/สี", "เอฟเฟกต์").forEachIndexed { i, label ->
                    Text(
                        label,
                        color = if (tab == i) Yellow else Color.White,
                        fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.clickable { tab = i }.padding(6.dp),
                    )
                }
            }

            Column(Modifier.fillMaxWidth().heightIn(min = 150.dp).padding(bottom = 12.dp)) {
                when (tab) {
                    0 -> {
                        if (!look.isOriginal) LabeledSlider("ความเข้ม", intensity, { intensity = it })
                        FilterStrip(thumb = thumb, selectedId = lookId, onSelect = { lookId = it.id })
                    }

                    1 -> {
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp),
                        ) {
                            items(AdjKey.entries) { k ->
                                val sel = k == adjKey
                                val changed = adj.get(k) != 0f
                                Text(
                                    k.label + if (changed) " •" else "",
                                    color = if (sel) Color.Black else Color.White,
                                    fontSize = 13.sp,
                                    modifier = Modifier.clip(RoundedCornerShape(50))
                                        .background(if (sel) Yellow else Color.White.copy(alpha = 0.12f))
                                        .clickable { adjKey = k }
                                        .padding(horizontal = 12.dp, vertical = 6.dp),
                                )
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        LabeledSlider(
                            adjKey.label,
                            adj.get(adjKey),
                            { adj = adj.with(adjKey, it) },
                            range = if (adjKey.signed) -1f..1f else 0f..1f,
                            showSigned = adjKey.signed,
                        )
                        TextButton(
                            onClick = { adj = adj.copy(brightness = 0f, contrast = 0f, saturation = 0f, warmth = 0f, tint = 0f, fade = 0f) },
                            modifier = Modifier.padding(start = 8.dp),
                        ) { Text("รีเซ็ตทั้งหมด", color = Color.White.copy(alpha = 0.7f)) }
                    }

                    else -> {
                        LabeledSlider("เกรนฟิล์ม", adj.grain, { adj = adj.copy(grain = it) })
                        LabeledSlider("ขอบมืด", adj.vignette, { adj = adj.copy(vignette = it) })
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("วันที่สีส้มแบบกล้องฟิล์ม", color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            Switch(
                                checked = stamp,
                                onCheckedChange = { stamp = it },
                                colors = SwitchDefaults.colors(checkedTrackColor = Orange),
                            )
                        }
                        Text(
                            "ขอบภาพ",
                            color = Color.White,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(start = 16.dp, top = 4.dp, bottom = 6.dp),
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp),
                        ) {
                            items(Border.entries) { b -> Pill(b.label, b == border) { border = b } }
                        }
                    }
                }
            }
        }

        if (saving) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Yellow)
                    Spacer(Modifier.height(12.dp))
                    Text("กำลังบันทึกที่ความละเอียดเต็ม…", color = Color.White)
                }
            }
        }
    }
}
