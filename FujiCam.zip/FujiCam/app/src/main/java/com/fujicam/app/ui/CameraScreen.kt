package com.fujicam.app.ui

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.media.MediaActionSound
import android.net.Uri
import android.util.Size
import android.view.OrientationEventListener
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ZoomState
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.ImageShader
import androidx.compose.ui.graphics.ShaderBrush
import androidx.compose.ui.graphics.TileMode
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Observer
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.lifecycleScope
import com.fujicam.app.camera.CamMode
import com.fujicam.app.camera.CameraEngine
import com.fujicam.app.camera.VideoPipeline
import com.fujicam.app.filters.Adjustments
import com.fujicam.app.filters.CM
import com.fujicam.app.filters.FilmLook
import com.fujicam.app.filters.FilmLooks
import com.fujicam.app.filters.FilterEngine
import com.fujicam.app.util.BitmapIO
import com.fujicam.app.util.MediaSaver
import com.fujicam.app.util.Prefs
import com.fujicam.app.util.findActivity
import com.fujicam.app.util.formatNanos
import com.fujicam.app.util.hasPermission
import com.fujicam.app.util.toast
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt

private fun newPreviewView(context: Context) = PreviewView(context).apply {
    // COMPATIBLE = ใช้ TextureView ทำให้ใส่ฟิลเตอร์สดบนพรีวิวได้
    implementationMode = PreviewView.ImplementationMode.COMPATIBLE
    scaleType = PreviewView.ScaleType.FILL_CENTER
    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
}

private fun <T : View> T.detachFromParent(): T {
    (parent as? ViewGroup)?.removeView(this)
    return this
}

@Composable
fun CameraScreen(
    lookId: String,
    intensity: Float,
    onLookChange: (String) -> Unit,
    onIntensityChange: (Float) -> Unit,
    onPickPhoto: () -> Unit,
    onOpenFrameGrab: (Uri?) -> Unit,
    onEditUri: (Uri) -> Unit,
    registerVolumeKey: ((() -> Unit)?) -> Unit,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val uiScope = rememberCoroutineScope()
    val workScope = lifecycleOwner.lifecycleScope // งานบันทึกไฟล์ไม่ถูกยกเลิกเมื่อเปลี่ยนหน้า
    val haptic = LocalHapticFeedback.current
    val prefs = remember { Prefs(context) }
    val engine = remember { CameraEngine(context.applicationContext) }
    val sound = remember { MediaActionSound() }
    val mainPreview = remember { newPreviewView(context) }
    val pipPreview = remember { newPreviewView(context) }

    var mode by rememberSaveable { mutableStateOf(CamMode.PHOTO) }
    var lens by rememberSaveable { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var flash by rememberSaveable { mutableIntStateOf(ImageCapture.FLASH_MODE_OFF) }
    var timerSec by rememberSaveable { mutableIntStateOf(0) }
    var grid by remember { mutableStateOf(prefs.grid) }
    var dateStamp by remember { mutableStateOf(prefs.dateStamp) }
    var mirrorFront by remember { mutableStateOf(prefs.mirrorFront) }
    var uhd by remember { mutableStateOf(prefs.uhd) }
    var showFilters by remember { mutableStateOf(false) }
    var showExposure by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    var bindCount by remember { mutableIntStateOf(0) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var minZoom by remember { mutableFloatStateOf(1f) }
    var maxZoom by remember { mutableFloatStateOf(1f) }
    var evIndex by remember { mutableIntStateOf(0) }
    var evMin by remember { mutableIntStateOf(0) }
    var evMax by remember { mutableIntStateOf(0) }
    var evStep by remember { mutableFloatStateOf(0f) }

    var recording by remember { mutableStateOf(false) }
    var paused by remember { mutableStateOf(false) }
    var recNanos by remember { mutableLongStateOf(0L) }
    var countdown by remember { mutableIntStateOf(0) }
    var processing by remember { mutableIntStateOf(0) }
    var blink by remember { mutableStateOf(false) }
    var focusAt by remember { mutableStateOf<Offset?>(null) }

    var lastUri by remember { mutableStateOf<Uri?>(null) }
    var lastIsVideo by remember { mutableStateOf(false) }
    var lastThumb by remember { mutableStateOf<ImageBitmap?>(null) }
    var filterThumb by remember { mutableStateOf<ImageBitmap?>(null) }

    val look = remember(lookId) { FilmLooks.byId(lookId) }
    val matrix = remember(lookId, intensity) { FilterEngine.matrixFor(look, Adjustments.NONE, intensity) }

    // ---------------- วงจรชีวิตกล้อง ----------------
    DisposableEffect(Unit) {
        sound.load(MediaActionSound.SHUTTER_CLICK)
        val window = context.findActivity()?.window
        window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val orientation = object : OrientationEventListener(context) {
            override fun onOrientationChanged(degrees: Int) {
                if (degrees != OrientationEventListener.ORIENTATION_UNKNOWN) {
                    engine.setTargetRotation(CameraEngine.rotationFor(degrees))
                }
            }
        }
        orientation.enable()
        onDispose {
            orientation.disable()
            engine.release()
            sound.release()
            window?.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    LaunchedEffect(mode, lens, uhd) {
        try {
            engine.ensureInit()
        } catch (e: Exception) {
            toast(context, "เปิดกล้องไม่ได้: ${e.message}")
            return@LaunchedEffect
        }
        if (mode.isDual && !engine.dualSupported()) {
            toast(context, "มือถือเครื่องนี้ไม่รองรับการเปิดกล้องหน้า-หลังพร้อมกัน")
            mode = CamMode.PHOTO
            return@LaunchedEffect
        }
        val ok = engine.bind(lifecycleOwner, mode, lens, mainPreview, pipPreview, uhd, flash)
        if (!ok) {
            toast(context, "เปิดโหมดนี้บนเครื่องนี้ไม่ได้")
            if (mode != CamMode.PHOTO) mode = CamMode.PHOTO
            return@LaunchedEffect
        }
        evIndex = 0
        val es = engine.camera?.cameraInfo?.exposureState
        if (es != null && es.isExposureCompensationSupported) {
            evMin = es.exposureCompensationRange.lower
            evMax = es.exposureCompensationRange.upper
            evStep = es.exposureCompensationStep.toFloat()
        } else {
            evMin = 0; evMax = 0
        }
        bindCount++
    }

    DisposableEffect(bindCount) {
        val zoomLive = engine.camera?.cameraInfo?.zoomState
        val observer = Observer<ZoomState> { z ->
            minZoom = z.minZoomRatio
            maxZoom = z.maxZoomRatio
            zoom = z.zoomRatio
        }
        zoomLive?.observe(lifecycleOwner, observer)
        onDispose { zoomLive?.removeObserver(observer) }
    }

    LaunchedEffect(flash, bindCount) { engine.applyFlash(mode, flash) }

    // ฟิลเตอร์สดบนพรีวิว
    LaunchedEffect(matrix) {
        val paint = Paint().apply { colorFilter = ColorMatrixColorFilter(matrix) }
        mainPreview.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
        pipPreview.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
    }

    // รูปตัวอย่างในแถบฟิลเตอร์ อัปเดตจากภาพกล้องจริง
    LaunchedEffect(showFilters, bindCount) {
        while (showFilters) {
            mainPreview.bitmap?.let { filterThumb = BitmapIO.scaleToMax(it, 160).asImageBitmap() }
            delay(1500)
        }
    }
    LaunchedEffect(blink) {
        if (blink) {
            delay(110)
            blink = false
        }
    }
    LaunchedEffect(focusAt) {
        if (focusAt != null) {
            delay(1600)
            focusAt = null
        }
    }

    // ---------------- การกระทำ ----------------
    fun setLast(uri: Uri?, isVideo: Boolean) {
        if (uri == null) return
        lastUri = uri
        lastIsVideo = isVideo
        workScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                runCatching { context.contentResolver.loadThumbnail(uri, Size(256, 256), null) }.getOrNull()
            }
            lastThumb = bmp?.asImageBitmap()
        }
    }

    fun onVideoFinished(file: File, ok: Boolean, colorMatrix: FloatArray) {
        if (!ok) {
            file.delete()
            toast(context, "บันทึกวิดีโอไม่สำเร็จ")
            return
        }
        processing++
        workScope.launch {
            try {
                if (!CM.isIdentity(colorMatrix)) toast(context, "กำลังใส่ฟิลเตอร์ให้วิดีโอ…")
                val uri = VideoPipeline.finish(context, file, colorMatrix)
                setLast(uri, true)
                toast(context, if (uri != null) "บันทึกวิดีโอแล้ว" else "บันทึกวิดีโอไม่สำเร็จ")
            } finally {
                processing--
            }
        }
    }

    fun takePhoto(silent: Boolean = false) {
        val ic = engine.imageCapture ?: run {
            toast(context, "โหมดนี้ถ่ายภาพนิ่งไม่ได้บนเครื่องนี้")
            return
        }
        val mirror = lens == CameraSelector.LENS_FACING_FRONT && mirrorFront
        val snapLook = look
        val snapIntensity = intensity
        val stamp = dateStamp
        if (!silent) sound.play(MediaActionSound.SHUTTER_CLICK)
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        blink = true
        processing++
        workScope.launch {
            try {
                val raw = engine.capture(ic, mirror)
                val uri = withContext(Dispatchers.Default) {
                    val out = FilterEngine.render(raw, snapLook, Adjustments.NONE, snapIntensity, stamp)
                    raw.recycle()
                    MediaSaver.saveBitmap(context, out).also { out.recycle() }
                }
                if (uri == null) toast(context, "บันทึกรูปไม่สำเร็จ")
                setLast(uri, false)
            } catch (e: Exception) {
                toast(context, "ถ่ายไม่สำเร็จ: ${e.message}")
            } finally {
                processing--
            }
        }
    }

    fun takeDualPhoto() {
        val icBack = engine.imageCapture
        val icFront = engine.imageCapture2
        if (icBack == null || icFront == null) return
        val snapLook = look
        val snapIntensity = intensity
        val stamp = dateStamp
        val mirror = mirrorFront
        sound.play(MediaActionSound.SHUTTER_CLICK)
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
        blink = true
        processing++
        workScope.launch {
            try {
                val (back, front) = coroutineScope {
                    val b = async { engine.capture(icBack, false) }
                    val f = async { engine.capture(icFront, mirror) }
                    b.await() to f.await()
                }
                val uri = withContext(Dispatchers.Default) {
                    val b = FilterEngine.render(back, snapLook, Adjustments.NONE, snapIntensity, false)
                    back.recycle()
                    val f = FilterEngine.render(front, snapLook, Adjustments.NONE, snapIntensity, false)
                    front.recycle()
                    val combo = FilterEngine.composeDual(b, f)
                    if (stamp) FilterEngine.drawDateStamp(combo, System.currentTimeMillis())
                    val u = MediaSaver.saveBitmap(context, combo, prefix = "FJC_DUAL")
                    MediaSaver.saveBitmap(context, b, prefix = "FJC_BACK")
                    MediaSaver.saveBitmap(context, f, prefix = "FJC_FRONT")
                    combo.recycle(); b.recycle(); f.recycle()
                    u
                }
                setLast(uri, false)
            } catch (e: Exception) {
                toast(context, "ถ่ายคู่ไม่สำเร็จ: ${e.message}")
            } finally {
                processing--
            }
        }
    }

    fun startVideo() {
        val vc = engine.videoCapture ?: return
        val snap = matrix
        val audio = hasPermission(context, Manifest.permission.RECORD_AUDIO)
        val file = File(context.cacheDir, "rec_${System.currentTimeMillis()}.mp4")
        sound.play(MediaActionSound.START_VIDEO_RECORDING)
        recNanos = 0L
        paused = false
        try {
            engine.startRecording(true, vc, file, audio, onStatus = { recNanos = it }) { f, ok -> onVideoFinished(f, ok, snap) }
            recording = true
        } catch (e: Exception) {
            toast(context, "เริ่มอัดวิดีโอไม่ได้: ${e.message}")
        }
    }

    fun startDualVideo() {
        val v1 = engine.videoCapture
        val v2 = engine.videoCapture2
        if (v1 == null || v2 == null) return
        val snap = matrix
        val audio = hasPermission(context, Manifest.permission.RECORD_AUDIO)
        val t = System.currentTimeMillis()
        sound.play(MediaActionSound.START_VIDEO_RECORDING)
        recNanos = 0L
        paused = false
        try {
            engine.startRecording(true, v1, File(context.cacheDir, "dual_back_$t.mp4"), audio, onStatus = { recNanos = it }) { f, ok ->
                onVideoFinished(f, ok, snap)
            }
            engine.startRecording(false, v2, File(context.cacheDir, "dual_front_$t.mp4"), false, onStatus = {}) { f, ok ->
                onVideoFinished(f, ok, snap)
            }
            recording = true
        } catch (e: Exception) {
            engine.stopRecordings()
            toast(context, "อัดคู่ไม่ได้: ${e.message}")
        }
    }

    fun stopVideo() {
        engine.stopRecordings()
        recording = false
        paused = false
        sound.play(MediaActionSound.STOP_VIDEO_RECORDING)
    }

    fun togglePause() {
        if (paused) engine.resumeRecordings() else engine.pauseRecordings()
        paused = !paused
    }

    suspend fun runCountdown() {
        for (i in timerSec downTo 1) {
            countdown = i
            delay(1000)
        }
        countdown = 0
    }

    val onShutter: () -> Unit = {
        if (countdown == 0) {
            when (mode) {
                CamMode.PHOTO -> uiScope.launch { runCountdown(); takePhoto() }
                CamMode.DUAL_PHOTO -> uiScope.launch { runCountdown(); takeDualPhoto() }
                CamMode.VIDEO -> if (recording) stopVideo() else uiScope.launch { runCountdown(); startVideo() }
                CamMode.DUAL_VIDEO -> if (recording) stopVideo() else uiScope.launch { runCountdown(); startDualVideo() }
            }
        }
    }

    // กดปุ่มเพิ่ม/ลดเสียงเพื่อถ่าย
    val latestShutter by rememberUpdatedState(onShutter)
    DisposableEffect(Unit) {
        registerVolumeKey { latestShutter() }
        onDispose { registerVolumeKey(null) }
    }

    fun flip() {
        if (recording || mode.isDual) return
        lens = if (lens == CameraSelector.LENS_FACING_BACK) CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        if (lens == CameraSelector.LENS_FACING_FRONT) flash = ImageCapture.FLASH_MODE_OFF
        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
    }

    fun setZoom(z: Float) {
        val target = z.coerceIn(minZoom, max(minZoom, maxZoom))
        engine.camera?.cameraControl?.setZoomRatio(target)
        zoom = target
    }

    fun focus(p: Offset) {
        val cam = engine.camera ?: return
        val point = mainPreview.meteringPointFactory.createPoint(p.x, p.y)
        val action = FocusMeteringAction.Builder(point, FocusMeteringAction.FLAG_AF or FocusMeteringAction.FLAG_AE)
            .setAutoCancelDuration(4, TimeUnit.SECONDS)
            .build()
        cam.cameraControl.startFocusAndMetering(action)
        focusAt = p
    }

    fun openLast() {
        val u = lastUri
        if (u == null) {
            onPickPhoto()
            return
        }
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(u, if (lastIsVideo) "video/*" else "image/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        try {
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            toast(context, "ไม่พบแอพสำหรับเปิดไฟล์")
        }
    }

    fun longPressLast() {
        val u = lastUri ?: return
        if (lastIsVideo) onOpenFrameGrab(u) else onEditUri(u)
    }

    fun cycleFlash() {
        flash = if (mode.isVideo) {
            if (flash == ImageCapture.FLASH_MODE_OFF) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
        } else {
            when (flash) {
                ImageCapture.FLASH_MODE_OFF -> ImageCapture.FLASH_MODE_AUTO
                ImageCapture.FLASH_MODE_AUTO -> ImageCapture.FLASH_MODE_ON
                else -> ImageCapture.FLASH_MODE_OFF
            }
        }
    }

    // ---------------- หน้าจอ ----------------
    val flashUsable = !mode.isDual && lens == CameraSelector.LENS_FACING_BACK

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Column(Modifier.fillMaxSize().systemBarsPadding()) {

            // แถบบน
            Row(
                Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                TopIcon(flashIcon(flash), if (flash != ImageCapture.FLASH_MODE_OFF) Yellow else Color.White, enabled = flashUsable) {
                    cycleFlash()
                }
                TopIcon(timerIcon(timerSec), if (timerSec > 0) Yellow else Color.White, enabled = !recording) {
                    timerSec = when (timerSec) {
                        0 -> 3
                        3 -> 10
                        else -> 0
                    }
                }
                TopIcon(if (grid) Icons.Filled.GridOn else Icons.Filled.GridOff, if (grid) Yellow else Color.White) {
                    grid = !grid
                    prefs.grid = grid
                }
                TopIcon(Icons.Filled.DateRange, if (dateStamp) Orange else Color.White) {
                    dateStamp = !dateStamp
                    prefs.dateStamp = dateStamp
                    toast(context, if (dateStamp) "เปิดวันที่แบบกล้องฟิล์ม" else "ปิดวันที่")
                }
                TopIcon(Icons.Filled.Exposure, if (showExposure) Yellow else Color.White, enabled = evMax > evMin) {
                    showExposure = !showExposure
                }
                if (mode == CamMode.VIDEO) {
                    Text(
                        if (uhd) "4K" else "HD",
                        color = if (uhd) Yellow else Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        modifier = Modifier.clip(RoundedCornerShape(6.dp))
                            .border(1.dp, if (uhd) Yellow else Color.White, RoundedCornerShape(6.dp))
                            .clickable(enabled = !recording) {
                                uhd = !uhd
                                prefs.uhd = uhd
                            }
                            .padding(horizontal = 8.dp, vertical = 3.dp),
                    )
                }
                Spacer(Modifier.weight(1f))
                TopIcon(Icons.Filled.PhotoFilter, if (showFilters) Yellow else Color.White) { showFilters = !showFilters }
                Box {
                    TopIcon(Icons.Filled.MoreVert) { menuOpen = true }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(
                            text = { Text("นำเข้ารูปจากแกลเลอรี่มาแต่ง") },
                            leadingIcon = { Icon(Icons.Filled.PhotoLibrary, null) },
                            onClick = { menuOpen = false; onPickPhoto() },
                        )
                        DropdownMenuItem(
                            text = { Text("แคปภาพจากวิดีโอ (ชัดเต็ม)") },
                            leadingIcon = { Icon(Icons.Filled.Movie, null) },
                            onClick = { menuOpen = false; onOpenFrameGrab(null) },
                        )
                        val lu = lastUri
                        if (lastIsVideo && lu != null) {
                            DropdownMenuItem(
                                text = { Text("แคปภาพจากวิดีโอที่เพิ่งอัด") },
                                leadingIcon = { Icon(Icons.Filled.Videocam, null) },
                                onClick = { menuOpen = false; onOpenFrameGrab(lu) },
                            )
                        }
                        DropdownMenuItem(
                            text = { Text("กลับด้านรูปกล้องหน้าแบบกระจก") },
                            leadingIcon = {
                                Icon(if (mirrorFront) Icons.Filled.CheckBox else Icons.Filled.CheckBoxOutlineBlank, null)
                            },
                            onClick = {
                                mirrorFront = !mirrorFront
                                prefs.mirrorFront = mirrorFront
                            },
                        )
                    }
                }
            }

            // พื้นที่พรีวิว
            Box(Modifier.weight(1f).fillMaxWidth()) {
                val ratio = if (mode == CamMode.VIDEO) 9f / 16f else 3f / 4f
                Box(Modifier.align(Alignment.Center).aspectRatio(ratio)) {
                    AndroidView(factory = { mainPreview.detachFromParent() }, modifier = Modifier.fillMaxSize())
                    EffectOverlay(look, intensity, dateStamp, Modifier.fillMaxSize())
                    if (grid) GridOverlay(Modifier.fillMaxSize())
                    Box(
                        Modifier.fillMaxSize()
                            .pointerInput(Unit) {
                                detectTapGestures(onTap = { focus(it) }, onDoubleTap = { flip() })
                            }
                            .pointerInput(Unit) {
                                detectTransformGestures { _, _, zoomChange, _ ->
                                    if (zoomChange != 1f) setZoom(zoom * zoomChange)
                                }
                            },
                    )
                    focusAt?.let { FocusRing(it) }
                    if (mode.isDual) {
                        AndroidView(
                            factory = { pipPreview.detachFromParent() },
                            modifier = Modifier.align(Alignment.TopStart).padding(12.dp)
                                .fillMaxWidth(0.32f).aspectRatio(3f / 4f)
                                .clip(RoundedCornerShape(14.dp))
                                .border(2.dp, Color.White, RoundedCornerShape(14.dp)),
                        )
                    }
                    if (recording) {
                        RecordBadge(recNanos, paused, Modifier.align(Alignment.TopCenter).padding(top = 10.dp))
                    }
                    if (!look.isOriginal && !showFilters) {
                        Text(
                            look.name,
                            color = Color.White,
                            fontSize = 12.sp,
                            modifier = Modifier.align(Alignment.TopEnd).padding(10.dp)
                                .clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.5f))
                                .clickable { showFilters = true }
                                .padding(horizontal = 10.dp, vertical = 4.dp),
                        )
                    }
                    if (countdown > 0) {
                        Text(
                            "$countdown",
                            color = Color.White,
                            fontSize = 110.sp,
                            fontWeight = FontWeight.Light,
                            modifier = Modifier.align(Alignment.Center),
                        )
                    }
                    if (blink) Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.7f)))
                }

                Column(Modifier.align(Alignment.BottomCenter).fillMaxWidth()) {
                    if (showExposure && evMax > evMin) {
                        Row(
                            Modifier.fillMaxWidth().background(Color.Black.copy(alpha = 0.45f)).padding(horizontal = 14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Filled.Exposure, null, tint = Yellow)
                            Slider(
                                value = evIndex.toFloat(),
                                onValueChange = { v ->
                                    val i = v.roundToInt()
                                    if (i != evIndex) {
                                        evIndex = i
                                        engine.camera?.cameraControl?.setExposureCompensationIndex(i)
                                    }
                                },
                                valueRange = evMin.toFloat()..evMax.toFloat(),
                                steps = (evMax - evMin - 1).coerceAtLeast(0),
                                colors = yellowSlider(),
                                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                            )
                            Text(String.format(Locale.US, "%+.1f", evIndex * evStep), color = Color.White, fontSize = 12.sp)
                        }
                    }
                    ZoomChips(zoom, minZoom, maxZoom) { setZoom(it) }
                    if (showFilters) {
                        Column(Modifier.fillMaxWidth().background(Color.Black.copy(alpha = 0.6f)).padding(vertical = 8.dp)) {
                            if (!look.isOriginal) LabeledSlider("ความเข้ม", intensity, onIntensityChange)
                            FilterStrip(thumb = filterThumb, selectedId = lookId, onSelect = { onLookChange(it.id) })
                            if (mode.isVideo) {
                                Text(
                                    "วิดีโอ: ใส่สีฟิลเตอร์ให้หลังอัดเสร็จ (เกรน/ขอบมืด ใส่เฉพาะรูปถ่าย)",
                                    color = Color.White.copy(alpha = 0.6f),
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(start = 14.dp, top = 6.dp),
                                )
                            }
                        }
                    }
                }
            }

            ModeSelector(mode, enabled = !recording && countdown == 0) { m ->
                mode = m
                if (m.isDual) flash = ImageCapture.FLASH_MODE_OFF
                if (m.isVideo && flash == ImageCapture.FLASH_MODE_AUTO) flash = ImageCapture.FLASH_MODE_OFF
            }

            // แถบล่าง: รูปล่าสุด | ชัตเตอร์ | สลับกล้อง
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 30.dp, vertical = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (recording && mode == CamMode.VIDEO) {
                    RoundButton(if (paused) Icons.Filled.PlayArrow else Icons.Filled.Pause) { togglePause() }
                } else {
                    LastThumbnail(lastThumb, processing > 0, onTap = { openLast() }, onLongPress = { longPressLast() })
                }
                ShutterButton(mode, recording, onShutter)
                if (recording && mode == CamMode.VIDEO) {
                    // ถ่ายภาพนิ่งความละเอียดเต็มระหว่างอัดวิดีโอ
                    SnapButton(enabled = engine.imageCapture != null) { takePhoto(silent = true) }
                } else {
                    RoundButton(Icons.Filled.FlipCameraAndroid, enabled = !mode.isDual && !recording) { flip() }
                }
            }
        }
    }
}

// ======================= ชิ้นส่วนของหน้ากล้อง =======================

private fun flashIcon(f: Int): ImageVector = when (f) {
    ImageCapture.FLASH_MODE_ON -> Icons.Filled.FlashOn
    ImageCapture.FLASH_MODE_AUTO -> Icons.Filled.FlashAuto
    else -> Icons.Filled.FlashOff
}

private fun timerIcon(s: Int): ImageVector = when (s) {
    3 -> Icons.Filled.Timer3
    10 -> Icons.Filled.Timer10
    else -> Icons.Filled.TimerOff
}

private fun fmtZoom(z: Float): String {
    val r = (z * 10f).roundToInt() / 10f
    return if (abs(r - r.roundToInt()) < 0.01f) r.roundToInt().toString() else String.format(Locale.US, "%.1f", r)
}

@Composable
private fun ZoomChips(zoom: Float, minZoom: Float, maxZoom: Float, onSelect: (Float) -> Unit) {
    val presets = remember(minZoom, maxZoom) {
        buildList {
            if (minZoom < 0.95f) add(minZoom)
            listOf(1f, 2f, 3f, 4f, 5f).filter { it <= maxZoom + 0.01f }.forEach { add(it) }
        }
    }
    if (presets.size < 2) return
    val active = presets.lastOrNull { it <= zoom + 0.05f } ?: presets.first()
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), horizontalArrangement = Arrangement.Center) {
        Row(
            Modifier.clip(RoundedCornerShape(50)).background(Color.Black.copy(alpha = 0.35f)).padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            presets.forEach { p ->
                val selected = p == active
                Box(
                    Modifier.size(if (selected) 40.dp else 32.dp).clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.55f))
                        .clickable { onSelect(p) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(
                        if (selected) fmtZoom(zoom) + "×" else fmtZoom(p),
                        color = if (selected) Yellow else Color.White,
                        fontSize = if (selected) 12.sp else 11.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }
            }
        }
    }
}

@Composable
private fun ModeSelector(current: CamMode, enabled: Boolean, onSelect: (CamMode) -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally),
    ) {
        CamMode.entries.forEach { m ->
            val sel = m == current
            Text(
                m.label,
                color = when {
                    sel -> Yellow
                    enabled -> Color.White
                    else -> Color.White.copy(alpha = 0.35f)
                },
                fontSize = 14.sp,
                fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                modifier = Modifier.clip(RoundedCornerShape(8.dp))
                    .clickable(enabled = enabled && !sel) { onSelect(m) }
                    .padding(horizontal = 6.dp, vertical = 6.dp),
            )
        }
    }
}

@Composable
private fun ShutterButton(mode: CamMode, recording: Boolean, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.88f else 1f, label = "shutter")
    val inner = if (mode.isVideo) Color(0xFFFF3B30) else Color.White
    Box(
        Modifier.size(80.dp).clickable(interactionSource = interaction, indication = null, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 4.dp.toPx()
            drawCircle(Color.White, radius = size.minDimension / 2f - stroke / 2f, style = Stroke(stroke))
        }
        if (recording) {
            Box(Modifier.size(30.dp).clip(RoundedCornerShape(7.dp)).background(inner))
        } else {
            Box(Modifier.size(64.dp).scale(scale).clip(CircleShape).background(inner))
        }
    }
}

@Composable
private fun SnapButton(enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(54.dp).clip(CircleShape).border(2.dp, Color.White, CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Box(Modifier.size(42.dp).clip(CircleShape).background(Color.White.copy(alpha = if (enabled) 1f else 0.3f)))
    }
}

@Composable
private fun LastThumbnail(thumb: ImageBitmap?, busy: Boolean, onTap: () -> Unit, onLongPress: () -> Unit) {
    val tap by rememberUpdatedState(onTap)
    val longPress by rememberUpdatedState(onLongPress)
    Box(
        Modifier.size(54.dp).clip(RoundedCornerShape(10.dp)).background(Panel)
            .border(1.dp, Color.White.copy(alpha = 0.6f), RoundedCornerShape(10.dp))
            .pointerInput(Unit) { detectTapGestures(onTap = { tap() }, onLongPress = { longPress() }) },
        contentAlignment = Alignment.Center,
    ) {
        if (thumb != null) {
            Image(thumb, null, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Icon(Icons.Filled.PhotoLibrary, null, tint = Color.White)
        }
        if (busy) CircularProgressIndicator(Modifier.size(22.dp), color = Yellow, strokeWidth = 2.dp)
    }
}

@Composable
private fun RecordBadge(nanos: Long, paused: Boolean, modifier: Modifier) {
    Text(
        text = formatNanos(nanos) + if (paused) "  ⏸" else "",
        modifier = modifier.clip(RoundedCornerShape(6.dp)).background(Color(0xFFFF3B30))
            .padding(horizontal = 10.dp, vertical = 3.dp),
        color = Color.White,
        fontFamily = FontFamily.Monospace,
        fontWeight = FontWeight.SemiBold,
        fontSize = 15.sp,
    )
}

@Composable
private fun FocusRing(at: Offset) {
    val half = with(LocalDensity.current) { 36.dp.toPx() }
    Box(
        Modifier.offset { IntOffset((at.x - half).roundToInt(), (at.y - half).roundToInt()) }
            .size(72.dp)
            .border(1.5.dp, Yellow, RoundedCornerShape(4.dp)),
    )
}

@Composable
private fun GridOverlay(modifier: Modifier) {
    Canvas(modifier) {
        val c = Color.White.copy(alpha = 0.35f)
        val sw = 1.dp.toPx()
        for (i in 1..2) {
            val x = size.width * i / 3f
            val y = size.height * i / 3f
            drawLine(c, Offset(x, 0f), Offset(x, size.height), sw)
            drawLine(c, Offset(0f, y), Offset(size.width, y), sw)
        }
    }
}

/** เอฟเฟกต์ที่ไม่ใช่สี (แสงรั่ว / เกรน / ขอบมืด / วันที่) แสดงทับพรีวิว */
@Composable
private fun EffectOverlay(look: FilmLook, intensity: Float, dateStamp: Boolean, modifier: Modifier) {
    val vignette = FilterEngine.vignetteOf(look, Adjustments.NONE, intensity)
    val leak = FilterEngine.leakOf(look, intensity)
    val grain = FilterEngine.grainOf(look, Adjustments.NONE, intensity)
    val noiseBrush = remember {
        ShaderBrush(ImageShader(FilterEngine.grainTile.asImageBitmap(), TileMode.Repeated, TileMode.Repeated))
    }
    Box(modifier) {
        if (vignette > 0f || leak > 0f || grain > 0f) {
            Canvas(Modifier.fillMaxSize()) {
                if (leak > 0f) {
                    drawRect(
                        brush = Brush.radialGradient(
                            0f to Color(1f, 0.43f, 0.12f, leak * 0.86f),
                            0.45f to Color(1f, 0.24f, 0.24f, leak * 0.43f),
                            1f to Color.Transparent,
                            center = Offset(size.width * 0.95f, size.height * 0.05f),
                            radius = size.maxDimension * 0.8f,
                        ),
                        blendMode = BlendMode.Screen,
                    )
                }
                if (vignette > 0f) {
                    drawRect(
                        brush = Brush.radialGradient(
                            0f to Color.Transparent,
                            0.5f to Color.Transparent,
                            1f to Color.Black.copy(alpha = (vignette * 0.92f).coerceIn(0f, 1f)),
                            center = center,
                            radius = hypot(size.width / 2f, size.height / 2f),
                        ),
                    )
                }
                if (grain > 0f) {
                    drawRect(brush = noiseBrush, alpha = (grain * 0.55f).coerceIn(0f, 1f), blendMode = BlendMode.Overlay)
                }
            }
        }
        if (dateStamp) DateStampLabel(Modifier.align(Alignment.BottomEnd).padding(14.dp))
    }
}
